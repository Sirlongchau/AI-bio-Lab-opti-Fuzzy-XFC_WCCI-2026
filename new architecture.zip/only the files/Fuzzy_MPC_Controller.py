from Casadi_mpc import MPCDirector
from risk_field import RiskField
from test_controller_fuzzy import FuzzyController
#from SacrificeController import SacrificeController
from dataclasses import dataclass
from supervisor import supervisor

class Controller:
    def __init__(self):
        self.fuzzy = FuzzyController()
        self.mpc = MPCDirector()
        self.sacrifice = FuzzyController() # placeholder for actual SacrificeController()
        self.supervisor = supervisor()
        #self.debug=debug() # placeholder for actual debug tools like FrameDebugger, RiskHeatmap, etc.
    
    def actions(self, ship_state, game_state):
        #self.debug.update(ship_state, game_state) # update debug tools with current state
        output = self.supervisor.select_mode.compute(ship_state, game_state) # get control output from supervisor
        return output