from risk_field import RiskField
from test_controller_fuzzy import FuzzyController
from Casadi_mpc import MPCController

class Supervisor:

    def __init__(self):

        self.controllers = {
            "fuzzy": FuzzyController(),
            "mpc": MPCController(),
            "sacrifice": FuzzyController(),
        }

        self.mode = "fuzzy"

        self.MPCfail = 0

        self.R_lo = 0.60
        self.R_hi = 0.70

    # ---------------------------------------------------------
    # Mode selection only
    # ---------------------------------------------------------

    def select_mode(self, ship_state, game_state):

        risks = RiskField.compute_all(ship_state, game_state)
        R_global = RiskField.aggregate(risks)

        if ship_state.respawn_time_left > 0:
            self.mode = "mpc"
            return

        if R_global <= self.R_lo:
            self.mode = "fuzzy"

        elif R_global >= self.R_hi:
            self.mode = "mpc"

        # else:
        # hysteresis → preserve current mode

    # ---------------------------------------------------------
    # Main routing function
    # ---------------------------------------------------------

    def compute(self, ship_state, game_state):

        self.select_mode(ship_state, game_state)

        controller = self.controllers[self.mode]

        output = controller.compute(ship_state, game_state)

        # -------------------------------------------------
        # MPC failure handling
        # -------------------------------------------------

        if ship_state.respawn_time_left > 0:
            self.MPCfail = 0

        if self.mode == "mpc":

            if not output.feasible:

                self.MPCfail += 1

                if self.MPCfail >= 10:

                    self.mode = "sacrifice"

                else:

                    self.mode = "fuzzy"

                controller = self.controllers[self.mode]

                output = controller.compute(ship_state, game_state)

            else:
                self.MPCfail = 0

        return output